package org.example.queue.service;

import org.example.queue.entity.Patient;
import org.example.queue.structure.BinarySearch;
import org.example.queue.structure.HashTable;
import org.example.queue.vo.PatientVO;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.ToIntFunction;

/**
 * 第三阶段的数据服务：对上层 Controller 提供"有序序列"与 VO 转换。
 *
 * 序列来源由 PatientSequenceProvider 决定（合并后为
 * QueueServicePatientSequenceProvider），每次实时取数，医生队列变化后
 * 等待时间会自动联动，保证折半查找 / 哈希表拿到的是与前端一致的最新数据。
 */
@Service
public class PatientDataService {

    /** 关键字 → HashTable 的 Key 枚举 */
    public static HashTable.Key toHashKey(String keyType) {
        return "ID".equalsIgnoreCase(keyType) ? HashTable.Key.ID : HashTable.Key.WaitTime;
    }

    /** 关键字 → 折半查找的比较函数 */
    public static ToIntFunction<Patient> toBinaryKey(String keyType) {
        return "ID".equalsIgnoreCase(keyType) ? BinarySearch.KeyID : BinarySearch.KeyWaitTime;
    }

    private final PatientSequenceProvider provider;

    public PatientDataService(PatientSequenceProvider provider) {
        this.provider = provider;
    }

    /** 按关键字升序（每次实时取数，等待时间与第二阶段队列保持同步） */
    public List<Patient> getSortedBy(String keyType) {
        ToIntFunction<Patient> key = toBinaryKey(keyType);
        List<Patient> sorted = new ArrayList<>(provider.sortedByWaitTime());
        sorted.sort(Comparator.comparingInt(key));
        BinarySearch.validateSorted(sorted.toArray(new Patient[0]), key, keyType);
        return sorted;
    }

    public Optional<Patient> findById(int id) {
        return provider.sortedByWaitTime().stream()
                .filter(p -> p.getId() == id)
                .findFirst();
    }

    /** 实体的编号是 int，VO 的编号是 "P001" 展示格式 */
    public static PatientVO toVO(Patient p) {
        if (p == null) return null;
        PatientVO vo = new PatientVO();
        vo.setId(String.format("P%03d", p.getId()));
        vo.setName(p.getName());
        vo.setArriveTime(p.getArriveTime() == null ? "" : p.getArriveTime().toString());
        vo.setTreatTime(p.getTreatTime());
        vo.setPriority(p.getPriority());
        vo.setTotalWaitTime(p.getTotalWaitTime());
        vo.setCurrentWaitTime(p.getCurrentWaitTime());
        return vo;
    }

    public static List<PatientVO> toVO(List<Patient> list) {
        List<PatientVO> out = new ArrayList<>(list.size());
        for (Patient p : list) out.add(toVO(p));
        return out;
    }
}