package org.example.queue.entity;

import java.time.LocalTime;

/**
 * 患者实体类
 * FIX: 等待时间拆成两个
 *   totalWaitTime   —— 总体等待时间：从到达时间到预计真正就诊的时间，加载/放弃时按调度规则预计
 *   currentWaitTime —— 即时等待时间：当前这一刻还要等多久才能就诊，随时钟推进实时更新
 */
public class Patient {
    private int id;           // Entity 内部存 int（从 txt 的 "P001" 剥掉 P 前缀解析而来）
    private String name;
    private LocalTime arriveTime;
    private int treatTime;    // 治疗耗时（分钟）
    private int priority;     // 优先级，数字越小越紧急
    private int totalWaitTime;   // FIX: 总体等待时间（分钟）
    private int currentWaitTime; // FIX: 即时等待时间（分钟）

    // 无参构造
    public Patient() {}

    // 全参构造（两个等待时间默认 0，由 QueueService 计算后回填）
    public Patient(int id, String name, LocalTime arriveTime, int treatTime, int priority) {
        this.id = id;
        this.name = name;
        this.arriveTime = arriveTime;
        this.treatTime = treatTime;
        this.priority = priority;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public LocalTime getArriveTime() { return arriveTime; }
    public void setArriveTime(LocalTime arriveTime) { this.arriveTime = arriveTime; }

    public int getTreatTime() { return treatTime; }
    public void setTreatTime(int treatTime) { this.treatTime = treatTime; }

    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }

    public int getTotalWaitTime() { return totalWaitTime; }
    public void setTotalWaitTime(int totalWaitTime) { this.totalWaitTime = totalWaitTime; }

    public int getCurrentWaitTime() { return currentWaitTime; }
    public void setCurrentWaitTime(int currentWaitTime) { this.currentWaitTime = currentWaitTime; }
}
