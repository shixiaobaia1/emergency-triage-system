package org.example.queue.service;

import org.example.queue.entity.Patient;

import java.util.List;

/**
 * 第三阶段的数据来源抽象。
 *
 * 第三阶段的两个结构（折半查找、哈希表）都以"第二阶段堆排序输出的有序序列"为输入，
 * 因此这里把序列来源抽象成接口。合并进根项目后，实现类为
 * QueueServicePatientSequenceProvider，直接复用第二阶段的 QueueService 队列。
 */
public interface PatientSequenceProvider {

    /**
     * 返回按等待时间升序排列的患者序列，即第二阶段大根堆排序的输出。
     *
     * @return 升序序列；数据尚未加载时返回空列表
     */
    List<Patient> sortedByWaitTime();
}