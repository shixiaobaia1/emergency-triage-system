package org.example.queue.service;

import org.example.queue.algorithm.CycleQueue;
import org.example.queue.algorithm.MaxHeap;
import org.example.queue.entity.Patient;
import org.example.queue.vo.PatientVO;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 大根堆排序服务——第二阶段
 * 从 QueueService 拿所有医生队列的患者快照 → 拍平成 CycleQueue → 建大根堆 → 堆排序（升序）
 * 排序依据是 waitTime（等待时间），升序结果适合第三阶段折半查找
 */
@Service
public class HeapService {

    private final QueueService queueService;

    private static final DateTimeFormatter HH_MM = DateTimeFormatter.ofPattern("HH:mm");

    public HeapService(QueueService queueService) {
        this.queueService = queueService;
    }

    //拿当前队列，按等待时间做大根堆排序
    public synchronized PatientVO[] heapSortByWaitTime() {
        List<Patient> snapshot = queueService.getAllPatientsSnapshot();
        if(snapshot.isEmpty()) return new PatientVO[0];
        Patient[] arr = snapshot.toArray(new Patient[0]);
        CycleQueue tmpQueue = new CycleQueue(arr.length);
        for(Patient p : arr) tmpQueue.insertPriority(p);
        //弄个循环队列数组进参数里
        MaxHeap maxHeap = new MaxHeap(tmpQueue);
        maxHeap.heapSort();  // 升序排序
        return toVOArray(maxHeap.getMaxHeap());
    }
    //把数组变成VO
    private PatientVO[] toVOArray(Patient[] patients) {
        PatientVO[] result = new PatientVO[patients.length];
        for(int i = 0; i < patients.length; i++) {
            result[i] = toVO(patients[i]);
        }
        return result;
    }

    private PatientVO toVO(Patient p) {
        PatientVO v = new PatientVO();
        v.setId(QueueService.formatId(p.getId()));  // 让id从int转回P什么什么的
        v.setName(p.getName());
        v.setArriveTime(p.getArriveTime().format(HH_MM));  //按格式返回VO里
        v.setTreatTime(p.getTreatTime());
        v.setPriority(p.getPriority());
        v.setWaitTime(p.getWaitTime());
        return v;
    }
}
